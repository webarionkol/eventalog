declare module '*';

declare var RazorpayCheckout: any;